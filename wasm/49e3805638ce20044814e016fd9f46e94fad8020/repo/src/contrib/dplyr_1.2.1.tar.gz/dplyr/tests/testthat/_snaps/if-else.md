# takes the common type of `true` and `false` (#6243)

    Code
      if_else(TRUE, 1, "x")
    Condition
      Error in `if_else()`:
      ! Can't combine `true` <double> and `false` <character>.

# includes `missing` in the common type computation if used

    Code
      if_else(TRUE, 1, 2, missing = "x")
    Condition
      Error in `if_else()`:
      ! Can't combine `true` <double> and `missing` <character>.

# `condition` must be logical (and isn't cast to logical!)

    Code
      if_else(1:10, 1, 2)
    Condition
      Error in `if_else()`:
      ! `condition` must be a logical vector, not an integer vector.

# `condition` can't be an array (#7723)

    Code
      if_else(array(TRUE), 1, 2)
    Condition
      Error in `if_else()`:
      ! `condition` must be a logical vector, not a logical 1D array.

# `true`, `false`, and `missing` must recycle to the size of `condition`

    Code
      if_else(x < 2, bad, x)
    Condition
      Error in `if_else()`:
      ! Can't recycle `true` (size 2) to size 3.

---

    Code
      if_else(x < 2, x, bad)
    Condition
      Error in `if_else()`:
      ! Can't recycle `false` (size 2) to size 3.

---

    Code
      if_else(x < 2, x, x, missing = bad)
    Condition
      Error in `if_else()`:
      ! Can't recycle `missing` (size 2) to size 3.

# must have empty dots

    Code
      if_else(TRUE, 1, 2, missing = 3, 4)
    Condition
      Error in `if_else()`:
      ! `...` must be empty.
      x Problematic argument:
      * ..1 = 4
      i Did you forget to name an argument?

# `ptype` overrides the common type

    Code
      if_else(TRUE, 1L, 2.5, ptype = integer())
    Condition
      Error in `if_else()`:
      ! Can't convert from `false` <double> to <integer> due to loss of precision.
      * Locations: 1

# `size` is deprecated

    Code
      x <- if_else(c(TRUE, FALSE), 1, 2, size = 2)
    Condition
      Warning:
      The `size` argument of `if_else()` is deprecated as of dplyr 1.2.0.

